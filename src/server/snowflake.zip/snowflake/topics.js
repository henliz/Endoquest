export function inferTopicFromHistory() {
  return 'endometriosis'; // force during initial build-out
}
